import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', padding: '50px' }}>
      <h1>NutriTech Pro</h1>
      <p>Gıda mühendisleri için profesyonel araçlar burada!</p>
    </div>
  );
}

export default App;